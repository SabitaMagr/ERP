﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NeoERP.ProjectManagement.Service.Models
{
    public class WebDesktopFolder
    {
        public string FOLDER_NAME { get; set; }
        public string ICON { get; set; }
        public string FOLDER_ID { get; set; }
        public string FOLDER_COLOR { get; set; }
    }
}
